import pgzrun,math
from pgzhelper import *
WIDTH =900
HEIGHT = 900



steve = Actor('steve')
steve.images = ['steve','toinen']
steveclick = False
gameover = False



steve.scale = 0.5
steve.scale = 1
steve.x = 0
steve.y = 0
WIDTH = 900
HEIGHT = 900
def on_mouse_down(pos):
    global steveclick
    if steve.collidepoint_pixel(pos):
        if steveclick == False:
            steveclick = True
        else:
            steveclick = False


toinen = Actor("toinen")
toinen.images = ['toinen','boom']
toinen.x = 900
toinen.y = 900
WIDTH = 900
HEIGHT = 900


print (steve.distance_to(toinen))
print(toinen.distance_to(steve))


background = Actor('background')
ticker = 0
suuntax = 0
suuntay = 0
laajuus = 9000

def draw():
    global steveclick, gameover, sekunttikello
    screen.clear()
    background.draw()
    steve.draw()
    toinen.draw()
    screen.draw.text(str(sekunttikello), (100,100), color="white", fontsize=80, shadow=(1.0,1.0))
    if steveclick == True:
        screen.draw.text("Discord: Ronsu 8948", steve.topright, color="white", fontsize=55, shadow=(1.0,1.0))
    if gameover == True:
        screen.draw.text("Game Over!!!", (20,20), color="red", fontsize=100, shadow=(1.0,1.0))



#kello#
sekunttikello = 0
def Aika():
    global sekunttikello, gameover, aaniefekti
    if gameover == True:
        
        aaniefekti.play()

        return;
    
    sekunttikello += 1
    print(str(sekunttikello))
    if sekunttikello == 10:
        sekunttikello=10
    timer()
def timer():
    clock.schedule(Aika, 1.0)
timer()
    
    
    
def update():
    global ticker,suuntax,suuntay,staminaincrease,stamina,staminaOnAarre, gameover
    if keyboard.m:
        musa.stop();
    if keyboard.p:
        musa.play();

    toinen.move_towards(steve, 10)
   
    toinen.x %= WIDTH
    toinen.y %= HEIGHT
    ticker += 1
    
    steve.x %= WIDTH
    steve.y %= HEIGHT
    ticker += 1
    
    if toinen.distance_to(steve) < 5 and gameover == False:
        gameover = True
        toinen.next_image()
        end = time.time()
        
    #keyboard#
    if gameover == False:    
        if keyboard[keys.A]:
            steve.angle = 180
            steve.flip_y = 1
            steve.direction = 180
            steve.move_in_direction(9)

        if keyboard[keys.D]:  # query the current "key pressed" state
            steve.angle = 360
            steve.flip_y = 0
            steve.direction = 0
            steve.move_in_direction(9)
        if keyboard[keys.S]:  # query the current "key pressed" state
            steve.direction = 270
            steve.move_in_direction(9)
        if keyboard[keys.W]:  # query the current "key pressed" state
            steve.direction = 90
            steve.move_in_direction(9)

    if keyboard[keys.SPACE]:  # query the current "key pressed" state
        suuntax = 0
        suuntay = 0

pygame.mixer.init()

aaniefekti = pygame.mixer.Sound('sounds/effect1.mp3');
musa = pygame.mixer.Sound('sounds/taustamusa.mp3');
musa.play()

pgzrun.go() 
